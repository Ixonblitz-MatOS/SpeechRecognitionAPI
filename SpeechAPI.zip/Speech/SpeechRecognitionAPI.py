import speech_recognition as sr
class Microphone:
    def listenCheck(self):
        r = sr.Recognizer()
        with sr.Microphone() as source:
            CheckChar = input("Enter the char you want to check for: ")
            check = str(f'{CheckChar}')
            audio = r.listen(source)
            # print('Speak Anything : ')
            # audio = r.listen(source)

            try:
                text = r.recognize_google(audio)
                test = ('{}'.format(text))
                print(f'You used {CheckChar}.')
                return test
            except:
                print('Sorry, could not recognize your voice')
                return None
    def listen(self):
        r = sr.Recognizer()
        with sr.Microphone() as source:
            audio = r.listen(source)
            # print('Speak Anything : ')
            # audio = r.listen(source)

            try:
                text = r.recognize_google(audio)
                test = ('{}'.format(text))
                return test
            except:
                print('Sorry, could not recognize your voice')
                return None